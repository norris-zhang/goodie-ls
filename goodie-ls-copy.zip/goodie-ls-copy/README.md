# goodie-ls
goodie local server

To list the usb devices:
> wmic path win32_usbcontrollerdevice get Dependent
\\DESKTOP-LGKKMA4\root\cimv2:Win32_PnPEntity.DeviceID="USBPRINT\CITIZENCT-S310II\7&341F92C8&1&USB002"


